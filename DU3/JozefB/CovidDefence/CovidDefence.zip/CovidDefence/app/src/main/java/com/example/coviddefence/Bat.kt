package com.example.coviddefence

import android.content.Context
import android.graphics.Bitmap

class Bat(
    override val context: Context,
    override var bitmap: Bitmap,
    override var path: MutableList<Pair<Float, Float>>,
    override val level : Level

) : Enemy {

    override var x = path[0].first
    override var y = path[0].second
    override var countDead = false
    override var walk = 0

    override var type = 1
    override var life = 4
    override val oneMove: Float = 18F
    override val reward = 40
    override var damage = 2
}