package com.example.coviddefence

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color

class Facemask(override val context: Context, override var x: Float, override var y: Float) : Tower{

    override var target: Enemy? = null
    override var fired = 0
    override val bullets = mutableListOf<Bullet>()


    override var bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.facemask)
    override var range = 250F
    override val rateOfFire = 20
    override val price = 100
    override val damage = 2
    override val bulletColor = Color.WHITE

}