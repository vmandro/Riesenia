package com.example.coviddefence

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.util.Log
import android.view.DragEvent
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView

class GamePanel(context : Context) : SurfaceView(context), SurfaceHolder.Callback {

    var thread : GameThread
    lateinit var levels : Levels
    var currentLevel : Level?

    init {
        holder.addCallback(this)
        thread = GameThread(this)
        isFocusable = true
        setBackgroundColor(Color.TRANSPARENT)

        currentLevel = null

    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        Log.d("SIZE", "$left, $top, $right, $bottom, $width, $height")
        levels = Levels(context, this)
        currentLevel = levels.restartLevelNum()
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        thread.start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        var retry = true
        thread.running = false
        while(retry) {
            try{
                thread.join()
                retry = false
            } catch (e : InterruptedException) {}
        }
    }

    fun restartLevel() {
        currentLevel = levels.restartLevelNum()
    }

    fun updateLevel() {
        currentLevel?.update()
    }

    fun drawLevel(canvas : Canvas) {
        if(currentLevel != null) {
            canvas.drawColor(Color.BLACK)
            currentLevel!!.draw(canvas)
        }
    }

    fun onMove(eventX : Float, eventY : Float) {

        currentLevel!!.tab.towerIcons.filter {it.clicked}.forEach {
            Log.d("MOVE", "${eventX - it.difX}")
            it.x = eventX - it.difX
            it.y = eventY - it.difY
            currentLevel?.places?.forEach { place ->
                if(place.isFree(it.x, it.y)) {
                    place.color = place.aboveColor
                } else {
                    place.color = place.noColor
                }
            }
        }
    }

    fun onDown(eventX : Float, eventY : Float) {
        currentLevel!!.tab.towerIcons.forEach {
            it.clicked = it.isIn(eventX, eventY)
            if(it.clicked) {
                it.setDif(eventX-it.x, eventY-it.y)
            }
        }
    }

    fun onUp(eventX : Float, eventY : Float) {
        var icon : Icon? = null
        currentLevel!!.tab.towerIcons.forEach {
            if(it.clicked) icon = it
            it.clicked = false
            it.setDif(0F, 0F)
            it.returnToDefault()
        }
        currentLevel!!.places.forEach {
            if(it.color != it.noColor) {
                if(icon != null) currentLevel?.addTower(it.x, it.y, icon!!.type)
                it.color = it.noColor
                it.empty = false
            }
        }
    }

}