package com.example.coviddefence

import android.content.Context
import android.graphics.Bitmap

interface Creator {

    val context : Context
    val desWidth : Int
    val desHeight : Int

    fun scaleBitmap(bitmap : Bitmap) : Bitmap {
        return Bitmap.createScaledBitmap(bitmap, desWidth, desHeight, false)
    }
}