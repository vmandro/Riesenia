package com.example.coviddefence

import android.content.Context
import android.graphics.*
import kotlin.random.Random

class Bacteria(
    override val context: Context,
    override var bitmap: Bitmap,
    override var path: MutableList<Pair<Float, Float>>,
    override val level : Level

) : Enemy {
    override var x = path[0].first
    override var y = path[0].second
    override var walk = 0
    override var countDead = false

    override var type = 0
    override var life = 8
    override val oneMove: Float = 8F
    override val reward = 20
    override var damage = 1
}