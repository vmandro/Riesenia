package com.example.coviddefence

import android.content.Context
import android.util.Log

class Levels(val context : Context, val gp : GamePanel) {

    val screenWidth = gp.width
    val screenHeight = gp.height

    val mapMaker : MapMaker

    var levelNum = 1

    init {
        mapMaker = MapMaker()
    }

    fun restartLevelNum() : Level{
        var res : Level? = null
        when(levelNum) {
            1 -> res = level1()
            2 -> res = level2()
            3 -> res = level3()
        }
        return res!!
    }

    fun nextLevel() : Level{
        var res : Level? = null
        if(levelNum == 3) levelNum = 1
        else levelNum += 1
        when(levelNum) {
            1 -> res = level1()
            2 -> res = level2()
            3 -> res = level3()
        }
        return res!!
    }


    fun level1() : Level {

        val tabScale = 0.15
        val tabWidth = (screenWidth * tabScale).toInt()
        val gameWidth = (screenWidth * (1 - tabScale)).toInt()

        // Level 1

        val map = mapMaker.createCovidMapOne()

        val desWidth = gameWidth / map.cols
        val desHeight = screenHeight / map.rows


        val pathPlace = mutableListOf<Pair<Float, Float>>()
        map.path.forEach { it ->
            pathPlace.add( Pair( (it.second*desWidth).toFloat() , (it.first*desHeight).toFloat())) }

        val towers : MutableList<Tower> = mutableListOf<Tower>()

        val towerIcons : MutableList<Icon> = mutableListOf<Icon>()
        towerIcons.add(FacemaskIcon(context))
        towerIcons.add(VaccineIcon(context))
        towerIcons.add(AntivirusIcon(context))

        Log.d("ICON", "ICON IN LEVELS")
        val tab = Tab(tabWidth, screenHeight, gameWidth, towerIcons)
        val money1 = 300
        var life1 = 5
        val bactValue = 10
        val batValue = 5
        val fakeValue = 0
        val rate = 25

        return Level(context,
            this,
            map.map,
            tab,
            towers,
            desWidth, desHeight,
            pathPlace,
            money1, life1,
            bactValue, batValue, fakeValue, rate)
    }

    fun level2() : Level {

        val tabScale = 0.15
        val tabWidth = (screenWidth * tabScale).toInt()
        val gameWidth = (screenWidth * (1 - tabScale)).toInt()

        val map = mapMaker.createCovidMapTwo()

        val desWidth = gameWidth / map.cols
        val desHeight = screenHeight / map.rows


        val pathPlace = mutableListOf<Pair<Float, Float>>()
        map.path.forEach { it ->
            pathPlace.add( Pair( (it.second*desWidth).toFloat() , (it.first*desHeight).toFloat())) }

        val towers : MutableList<Tower> = mutableListOf<Tower>()

        val towerIcons : MutableList<Icon> = mutableListOf<Icon>()
        towerIcons.add(FacemaskIcon(context))
        towerIcons.add(VaccineIcon(context))
        towerIcons.add(AntivirusIcon(context))

        Log.d("ICON", "ICON IN LEVELS")
        val tab = Tab(tabWidth, screenHeight, gameWidth, towerIcons)
        val money = 400
        var life = 5
        val bactValue = 15
        val batValue = 12
        val fakeValue = 8
        val rate = 25

        return Level(context,
            this,
            map.map,
            tab,
            towers,
            desWidth, desHeight,
            pathPlace,
            money, life,
            bactValue, batValue, fakeValue, rate)
    }

    fun level3() : Level {

        val tabScale = 0.15
        val tabWidth = (screenWidth * tabScale).toInt()
        val gameWidth = (screenWidth * (1 - tabScale)).toInt()

        // Level 3

        val map = mapMaker.createCovidMapOne()

        val desWidth = gameWidth / map.cols
        val desHeight = screenHeight / map.rows


        val pathPlace = mutableListOf<Pair<Float, Float>>()
        map.path.forEach { it ->
            pathPlace.add( Pair( (it.second*desWidth).toFloat() , (it.first*desHeight).toFloat())) }

        val towers : MutableList<Tower> = mutableListOf<Tower>()

        val towerIcons : MutableList<Icon> = mutableListOf<Icon>()
        towerIcons.add(FacemaskIcon(context))
        towerIcons.add(VaccineIcon(context))
        towerIcons.add(AntivirusIcon(context))

        Log.d("ICON", "ICON IN LEVELS")
        val tab = Tab(tabWidth, screenHeight, gameWidth, towerIcons)
        val money = 600
        var life = 5
        val bactValue = 15
        val batValue = 30
        val fakeValue = 20
        val rate = 10

        return Level(context,
            this,
            map.map,
            tab,
            towers,
            desWidth, desHeight,
            pathPlace,
            money, life,
            bactValue, batValue, fakeValue, rate)
    }

}