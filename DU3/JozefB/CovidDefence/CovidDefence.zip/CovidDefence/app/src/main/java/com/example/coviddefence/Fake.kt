package com.example.coviddefence

import android.content.Context
import android.graphics.Bitmap

class Fake(
    override val context: Context,
    override var bitmap: Bitmap,
    override var path: MutableList<Pair<Float, Float>>,
    override val level : Level

) : Enemy {
    override var x = path[0].first
    override var y = path[0].second
    override var walk = 0
    override var countDead = false

    override var type = 2
    override var life = 50
    override val oneMove: Float = 3F
    override val reward = 100
    override var damage = 3
}