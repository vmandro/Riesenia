package com.example.coviddefence

import android.content.Context
import android.graphics.*
import android.util.Log
import kotlin.math.sqrt

interface Enemy {
    val context : Context
    var x : Float
    var y : Float
    val oneMove : Float
    var bitmap : Bitmap
    var life : Int
    var path : MutableList<Pair<Float, Float>>
    var damage : Int
    var walk : Int //index of path where enemy is walking
    var type : Int
    val level : Level
    var countDead : Boolean
    val reward : Int

    fun draw(canvas : Canvas) {

        if (dead()) return
        if (isFinished()) return

        canvas.drawBitmap(bitmap, x, y, null)
        val paint = Paint()
        paint.color = Color.RED
        paint.textSize = (bitmap.width / 2).toFloat()
        paint.typeface = Typeface.DEFAULT_BOLD
        //canvas.drawCircle(x, y, 10F, paint)
        canvas.drawText(life.toString(), x, y, paint)

    }

    fun update() {

        if(dead()) {
            if(!countDead) {
                level.money += reward
                countDead = true
            }
            return
        }
        if (isFinished()) return

        val dist = distanceFrom(path[walk])
        if(dist < oneMove) {
            x = path[walk].first
            y = path[walk].second
            walk += 1
            return
        }

        if(x > path[walk].first) x -= oneMove
        else if(x < path[walk].first) x += oneMove

        if(y > path[walk].second) y -= oneMove
        else if(y < path[walk].second) y += oneMove

    }

    fun distanceFrom(pair : Pair<Float, Float>) : Float {
        return sqrt((x-pair.first)*(x-pair.first) + (y-pair.second)*(y-pair.second))
    }

    fun dead() : Boolean = life <= 0

    fun isFinished() = walk >= path.size

}