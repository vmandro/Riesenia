package com.example.coviddefence

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.Log
import kotlin.math.abs

interface Icon {

    val context : Context
    var bitmap : Bitmap
    var x : Float
    var y : Float
    var width : Int
    var height : Int
    var clicked : Boolean
    var difX : Float
    var difY : Float
    var defaultX : Float
    var defaultY : Float
    var type : Int

    fun scale(desWidth : Int, desHeight : Int) {
        bitmap = Bitmap.createScaledBitmap(bitmap, desWidth, desHeight, false)
        width = desWidth
        height = desHeight
    }

    fun draw(canvas : Canvas) {
        var paint = Paint()
        paint.color = Color.YELLOW
        canvas.drawCircle(x, y, 20F, paint)
        canvas.drawBitmap(bitmap, x, y, paint)
    }

    fun isIn(iX : Float, iY : Float) : Boolean =
         iX > x && iX < (x + width) && iY > y && iY < (y + height)

    fun setDif(newDifX : Float, newDifY : Float) {
        difX = newDifX
        difY = newDifY
    }

    fun returnToDefault() {
        x = defaultX
        y = defaultY
    }


}