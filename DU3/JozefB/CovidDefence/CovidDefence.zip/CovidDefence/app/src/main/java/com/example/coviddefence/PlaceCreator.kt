package com.example.coviddefence

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory

class PlaceCreator(override val context : Context,
                   override val desWidth: Int,
                   override val desHeight: Int
) : Creator{

    val pathBitmap = BitmapFactory.decodeResource(context.resources, R.drawable.dirt)
    val grassBitmap = BitmapFactory.decodeResource(context.resources, R.drawable.grass)
    val netherBitmap = BitmapFactory.decodeResource(context.resources, R.drawable.netherrack)
    val soulBitmap = BitmapFactory.decodeResource(context.resources, R.drawable.soulsand)

    fun newPlace(i : Int, j : Int, type : Int) : Place {
        val bitmap : Bitmap = when(type) {
            1 -> scaleBitmap(pathBitmap)
            2 -> scaleBitmap(soulBitmap)
            3 -> scaleBitmap(netherBitmap)
            else -> scaleBitmap(grassBitmap)
        }
        //treba vymenit i a j
        return Place(context, j, i, type, desWidth, desHeight, scaleBitmap(bitmap))
    }

}