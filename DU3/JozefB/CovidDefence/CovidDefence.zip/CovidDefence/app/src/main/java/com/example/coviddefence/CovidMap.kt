package com.example.coviddefence

class CovidMap(val map : Array<IntArray>,
            val rows : Int, val cols : Int,
            val path : MutableList<Pair<Int, Int>>) {
}