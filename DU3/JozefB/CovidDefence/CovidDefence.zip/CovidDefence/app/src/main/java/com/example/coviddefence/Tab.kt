package com.example.coviddefence

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.Log
import kotlin.math.min

class Tab(val tabWidth : Int, val tabHeight : Int, val startX : Int, val towerIcons : MutableList<Icon>){

    val space = tabHeight / (towerIcons.size + 1) //+1 for texts
    val iconSize = min(space, tabWidth)

    var money = 0
    var life = 0
    var moneyText = ""
    var lifeText = ""

    init {
        Log.d("ICON", "created $tabWidth $startX $space")
        Log.d("ICON", "iconsize $iconSize")

        for(i in towerIcons.indices) {
            towerIcons[i].scale(iconSize, iconSize)
            towerIcons[i].x = startX.toFloat() + tabWidth/2 - iconSize/2
            towerIcons[i].y = (space + i*space).toFloat()
            towerIcons[i].defaultX = towerIcons[i].x
            towerIcons[i].defaultY = towerIcons[i].y
            Log.d("ICON", "bitWidth ${towerIcons[i].bitmap.width}")
        }

    }

    fun update(newLife : Int, newMoney : Int) {
        money = newMoney
        life = newLife
        moneyText = "Money: $money "
        lifeText = "Life: $life"
    }

    fun draw(canvas : Canvas) {
        val paint = Paint()
        paint.color = Color.BLUE
        canvas.drawRect(startX.toFloat(), 0F,
            startX+tabWidth.toFloat(), tabHeight.toFloat(), paint)
        for(i in towerIcons.indices) {
            towerIcons[i].draw(canvas)
        }
        val paintText = Paint()
        paintText.color = Color.BLACK
        paintText.textSize = fontSize()
        canvas.drawText(moneyText, startX.toFloat(), (space/2).toFloat() - (fontSize() / 2), paintText)
        canvas.drawText(lifeText, startX.toFloat(), (space/2).toFloat() + (fontSize() / 2), paintText)

    }

    fun fontSize() : Float  {
        if(moneyText.isNotEmpty()) return (tabWidth / moneyText.length * 2).toFloat()
        return 0F
    }

}