package com.example.coviddefence

import android.content.Context

class TowerCreator(override val context : Context,
                   override val desWidth: Int,
                   override val desHeight: Int,
                   val level : Level
) : Creator {

    fun newTower(x : Float, y : Float, iconType : Int)  : Tower?{
        if(iconType == 0) { //Facemask
            val faceMoney = 100
            if(level.money >= faceMoney) {
                level.money -= faceMoney
                return newFaceMask(x, y)
            }
        }

        if(iconType == 1) { //Vaccine
            val vaccMoney = 200
            if(level.money >= vaccMoney) {
                level.money -= vaccMoney
                return newVaccine(x, y)
            }
        }

        if(iconType == 2) { //Antivirus
            val antiMoney = 500
            if(level.money >= antiMoney) {
                level.money -= antiMoney
                return newAntivirus(x, y)
            }
        }
        return null
    }

    fun newFaceMask(x : Float, y : Float) : Facemask{
        val nFacemask = Facemask(context, x, y)
        nFacemask.bitmap = scaleBitmap(nFacemask.bitmap)
        return nFacemask
    }

    fun newVaccine(x : Float, y : Float) : Vaccine{
        val nVaccine = Vaccine(context, x, y)
        nVaccine.bitmap = scaleBitmap(nVaccine.bitmap)
        return nVaccine
    }

    fun newAntivirus(x : Float, y : Float) : Antivirus{
        val nAntivirus = Antivirus(context, x, y)
        nAntivirus.bitmap = scaleBitmap(nAntivirus.bitmap)
        return nAntivirus
    }
}