package com.example.coviddefence

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color

class Antivirus(override val context: Context, override var x: Float, override var y: Float) : Tower{

    override var target: Enemy? = null
    override var fired = 0
    override val bullets = mutableListOf<Bullet>()


    override var bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.antivirus)
    override var range = 350F
    override val rateOfFire = 10
    override val price = 500
    override val damage = 3
    override val bulletColor = Color.YELLOW

}