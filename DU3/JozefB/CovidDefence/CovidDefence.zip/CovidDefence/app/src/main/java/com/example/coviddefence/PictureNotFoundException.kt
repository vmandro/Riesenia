package com.example.coviddefence


class PictureNotFoundException(message : String) : Exception(message) {
}