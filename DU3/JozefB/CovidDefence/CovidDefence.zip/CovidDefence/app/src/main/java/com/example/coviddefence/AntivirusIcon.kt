package com.example.coviddefence

import android.content.Context
import android.graphics.BitmapFactory

class AntivirusIcon(override val context : Context) : Icon {

    override var bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.antivirus)
    override var width = bitmap.width
    override var height = bitmap.height
    override var x = 500F
    override var y = 500F
    override var clicked = false
    override var difX = 500F
    override var difY = 500F
    override var defaultX = 500F
    override var defaultY = 500F
    override var type = 2
}