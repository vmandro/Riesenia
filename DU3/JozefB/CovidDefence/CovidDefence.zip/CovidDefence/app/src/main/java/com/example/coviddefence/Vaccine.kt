package com.example.coviddefence

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color

class Vaccine(override val context: Context, override var x: Float, override var y: Float) : Tower{

    override var target: Enemy? = null
    override var fired = 0
    override val bullets = mutableListOf<Bullet>()


    override var bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.vaccine)
    override var range = 600F
    override val rateOfFire = 100
    override val price = 200
    override val damage = 8
    override val bulletColor = Color.RED

}