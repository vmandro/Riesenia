package com.example.coviddefence

import android.content.Context
import android.graphics.Canvas
import android.util.Log

class Level(context: Context,
            val levels : Levels,
            map : Array<IntArray>,
            val tab : Tab,
            val towers : MutableList<Tower>,
            desWidth : Int, desHeight : Int,
            path : MutableList<Pair<Float, Float>>,
            var money : Int, var life : Int,
            val bacteriaValue : Int,
            val batValue : Int,
            val fakeValue : Int,
            val rate : Int)
{

    val places = mutableListOf<Place>()
    val placeCreator = PlaceCreator(context, desWidth, desHeight)
    val towerCreator = TowerCreator(context, desWidth, desHeight, this)
    val enemyCreator = EnemyCreator(context, desWidth, desHeight, 25, this)

    val enemiesSurvived = mutableListOf<Enemy>()

    init {
        Log.d("PLACES", "creating palces")
        for(i in map.indices) {
            for(j in map[i].indices){
                places.add(placeCreator.newPlace(i, j, map[i][j]))
            }
        }

        if(bacteriaValue > 0) enemyCreator.sendBacteriaWave(bacteriaValue, path)
        if(batValue > 0) enemyCreator.sendBatWave(batValue, path)
        if(fakeValue > 0) enemyCreator.sendFakeWave(fakeValue, path)
        if(bacteriaValue > 0) enemyCreator.sendBacteriaWave(bacteriaValue, path)
        if(batValue > 0) enemyCreator.sendBatWave(batValue, path)

        tab.money = money
        tab.life = life
    }


    fun update() {
        tab.update(life, money)
        enemyCreator.enemies.forEach {
            it.update()
            if(it.isFinished() && !enemiesSurvived.contains(it)) {
                enemySurvived(it)
                Log.d("FINISH", "Enemy Finish")
            }
        }
        gameCheck()
        towers.forEach { it.update(enemyCreator.enemies) }
        enemyCreator.update()
    }

    fun draw(canvas : Canvas) {

        places.forEach { it.draw(canvas) }
        //Log.d("DRAW", "1")
        enemyCreator.enemies.forEach { it.draw(canvas) }
        //Log.d("DRAW", "2")
        tab.draw(canvas)
        //Log.d("DRAW", "3")
        //towers.forEach { it.draw(canvas) } //toto pada
        for(i in towers.indices) towers[i].draw(canvas)
        //Log.d("DRAW", "4")
    }

    fun addTower(x : Float, y : Float, type : Int) {
        Log.d("ADD" ,"type $type")
        val newTower = towerCreator.newTower(x, y, type)
        if(newTower != null) towers.add(newTower)
    }

    fun enemySurvived(enemy : Enemy) {
        enemiesSurvived.add(enemy)
        life -= enemy.damage
        Log.d("FISHED", "${enemy.damage} $life")
    }

    fun gameCheck() {
        if(life <= 0) {
            Log.d("GAME", "LOST")
            levels.gp.restartLevel()
        }
        else if(enemyCreator.allEnemiesDead()) {
            Log.d("GAME", "WON")
            levels.gp.currentLevel = levels.nextLevel()
        }

    }


}