package com.example.coviddefence

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.Log
import kotlin.math.sqrt

interface Tower {
    val context : Context
    var x : Float
    var y : Float
    var bitmap : Bitmap
    var range : Float
    var target : Enemy?
    val rateOfFire : Int
    var fired : Int
    val bullets : MutableList<Bullet>
    val price : Int
    val damage : Int
    val bulletColor : Int

    fun update(enemies : MutableList<Enemy>) {
        var enemiesInRange = enemies.filter { inRange(it) && !it.dead() }
        target = enemiesInRange.minBy { distanceTo(it.x, it.y) }

        tryToFire()
        bullets.forEach { it.update() }

    }

    fun draw(canvas : Canvas) {
        canvas.drawBitmap(bitmap, x, y, null)
        var paint = Paint()
        paint.color = Color.argb(30, 173, 216, 230)
        canvas.drawCircle(x + (bitmap.width / 2), y + (bitmap.height / 2), range, paint)
        bullets.filter { !it.hit }.forEach { it.draw(canvas) }
    }

    fun inRange(enemy : Enemy) : Boolean =
        distanceTo(enemy.x + (enemy.bitmap.width / 2),
            enemy.y + (enemy.bitmap.height / 2)) <= range

    fun distanceTo(iX : Float, iY : Float) : Float =
        sqrt( (x-iX)*(x-iX) + (y-iY)*(y-iY) )

    fun tryToFire() {
        if(target != null && !target!!.dead()) {
            if(fired == 0) fireOnTarget()
            else fired -= 1
        }
    }

    fun fireOnTarget() {
        fired = rateOfFire
        bullets.add(Bullet(x + bitmap.width/2,
                y + bitmap.height/2,
                target!!,
                damage,
                bulletColor))

    }
}