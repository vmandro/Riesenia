package com.example.coviddefence

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.view.View

class MainActivity : AppCompatActivity() {

    lateinit var gp : GamePanel
    var screenWidth : Int = 0
    var screenHeight : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        gp = GamePanel(this)
        setContentView(gp)



    }
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        screenHeight = windowManager.defaultDisplay.height
        val clickX = event!!.x
        val clickY = event!!.y - 220//(screenHeight - gp.height)
        when (event.action) {
            MotionEvent.ACTION_UP -> gp.onUp(clickX, clickY)
            MotionEvent.ACTION_MOVE -> gp.onMove(clickX, clickY)
            MotionEvent.ACTION_DOWN -> gp.onDown(clickX, clickY)
        }
        return super.onTouchEvent(event)
    }
}