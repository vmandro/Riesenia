package com.example.coviddefence

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.text.Layout
import android.util.Log

class Place(context : Context,
            i : Int, j : Int, val type : Int,
            val desWidth : Int, val desHeight : Int,
            val bitmap : Bitmap
)
{

    val x = (i * desWidth).toFloat()
    val y = (j * desHeight).toFloat()
    var empty : Boolean = true
    var noColor = Color.TRANSPARENT
    var aboveColor = Color.RED
    var color = noColor

    fun draw(canvas : Canvas) {
        canvas.drawBitmap(bitmap, x, y, null)
        if(color != noColor) {
            Log.d("PLACE", "$x $y $desWidth $desHeight")
            val paint = Paint()
            paint.color =aboveColor
            canvas.drawRect(x, y, x + desWidth.toFloat(), y + desHeight.toFloat(), paint)
        }
    }

    fun isIn(iX : Float, iY : Float) : Boolean =
        iX > x && iX < (x + desWidth) && iY > y && iY < (y + desHeight)

    fun isFree(iX : Float, iY : Float) =
        empty && isIn(iX, iY) && type == 0

}