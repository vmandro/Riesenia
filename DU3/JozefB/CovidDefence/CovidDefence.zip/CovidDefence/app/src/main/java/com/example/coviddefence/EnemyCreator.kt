package com.example.coviddefence

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory

class EnemyCreator(override val context: Context,
                   override val desWidth: Int,
                   override val desHeight: Int,
                    val rate : Int,
                    val level : Level) : Creator{

    var rateCounter = 0
    private val bitmapBacteria: Bitmap? = BitmapFactory.decodeResource(context.resources, R.drawable.coronavirus)
    private val bitmapBat = BitmapFactory.decodeResource(context.resources, R.drawable.bat)
    private val bitmapFake = BitmapFactory.decodeResource(context.resources, R.drawable.fake)

    var addIndex = 0
    val enemiesToAdd = mutableListOf<Enemy>()
    val enemies = mutableListOf<Enemy>()

    fun newBacteria(path : MutableList<Pair<Float, Float>>) : Bacteria{
        if (bitmapBacteria == null) {
            throw PictureNotFoundException("coronavirus not found in drawable")
        }
        return Bacteria(context, scaleBitmap(bitmapBacteria), path, level)
    }

    fun newBat(path : MutableList<Pair<Float, Float>>) : Bat {
        if (bitmapBacteria == null) {
            throw PictureNotFoundException("coronavirus not found in drawable")
        }
        return Bat(context, scaleBitmap(bitmapBat), path, level)
    }

    fun newFake(path : MutableList<Pair<Float, Float>>) : Fake {
        if (bitmapFake == null) {
            throw PictureNotFoundException("coronavirus not found in drawable")
        }
        return Fake(context, scaleBitmap(bitmapFake), path, level)
    }

    fun sendBacteriaWave(amount : Int,
                         path : MutableList<Pair<Float, Float>>) {
        for(i in 0..amount) {
            enemiesToAdd.add(newBacteria(path))
        }
    }

    fun sendBatWave(amount : Int, path : MutableList<Pair<Float, Float>>) {
        for(i in 0..amount) {
            enemiesToAdd.add(newBat(path))
        }
    }

    fun sendFakeWave(amount : Int, path : MutableList<Pair<Float, Float>>) {
        for(i in 0..amount) {
            enemiesToAdd.add(newFake(path))
        }
    }

    fun update() {
        when {
            addIndex >= enemiesToAdd.size -> return

            rateCounter > 0 -> rateCounter -= 1

            else -> {
                enemies.add(enemiesToAdd[addIndex])
                addIndex += 1
                rateCounter = rate
            }
        }
    }

    fun allEnemiesDead() : Boolean {
        //.all(!dead()) pada na array index out of bounds
        if(enemies.size == 0) return false
        return enemies.all {it.dead() || it.isFinished()}
        /*
        var res = true
        enemies.forEach { if (it.dead()) res = false }
        return res*/
    }

}