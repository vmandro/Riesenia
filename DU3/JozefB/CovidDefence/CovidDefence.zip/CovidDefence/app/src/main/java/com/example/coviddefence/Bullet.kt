package com.example.coviddefence

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.Log
import kotlin.math.sqrt

class Bullet(startX : Float,
             startY : Float,
             val target : Enemy,
             val damage : Int,
             val color : Int) {

    var x  = startX
    var y = startY
    var radius = 10F
    var speed = 25F
    var paint = Paint()
    var hit = false

    var targetMidX = target.x + target.bitmap.width / 2
    var targetMidY = target.y + target.bitmap.height / 2

    init {
        paint.color = color
    }

    fun updateTargetPosition() {
        targetMidX = target.x + target.bitmap.width / 2
        targetMidY = target.y + target.bitmap.height / 2
    }

    fun update() {
        if(hit) return
        updateTargetPosition()
        val xDif = targetMidX - x
        val yDif = targetMidY - y
        val scale = speed / distanceToTarget()
        Log.d("TOWER", "scale: $scale")
        if(scale > 0.8) {
            hitTarget()
            return
        }
        val scaledX = xDif * scale
        val scaledY = yDif * scale
        x += scaledX
        y += scaledY
    }

    fun draw(canvas : Canvas) {
        if(hit) return
        Log.d("BULLET", "$x $y")
        canvas.drawCircle(x, y, radius, paint)
    }

    fun distanceToTarget() : Float =
        sqrt( (x-targetMidX)*(x-targetMidX)
                + (y-targetMidY)*(y-targetMidY) )

    fun hitTarget() {
        hit = true
        target.life -= damage
    }
}