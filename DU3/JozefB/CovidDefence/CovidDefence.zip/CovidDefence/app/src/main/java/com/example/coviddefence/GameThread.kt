package com.example.coviddefence

import android.graphics.Canvas

class GameThread(val gamePanel: GamePanel) : Thread() {
    var running = true
    val FRAME = 1000
    val FPS = 50
    val FRAME_PERIOD = FRAME / FPS

    override fun run() {
        super.run()
        val surfaceHolder = gamePanel.holder

        while(running) {
            var canvas : Canvas? = null

            try {
                canvas = surfaceHolder.lockCanvas()
                if(canvas == null) break
                else{
                    synchronized(surfaceHolder) {
                        var startTime = System.currentTimeMillis()

                        gamePanel.updateLevel()
                        gamePanel.drawLevel(canvas)

                        var elapsedTime = System.currentTimeMillis() - startTime
                        if(elapsedTime < FRAME_PERIOD) {
                            try {
                                Thread.sleep(FRAME_PERIOD - elapsedTime)
                            } catch (e : InterruptedException) {}
                        }
                    }
                }
            } finally {
                if (canvas != null) {
                    surfaceHolder.unlockCanvasAndPost(canvas)
                }
            }

        }
    }
}